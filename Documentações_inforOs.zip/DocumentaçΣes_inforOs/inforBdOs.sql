-- criando um banco de dados--
create database bdinfortec;
-- Escolhe o banco de dados
use bdinfortec;
-- Criando a tabela usuário
create table tecUsuario(
idUsu int primary key,
usuario varchar (50),
login varchar(20) not null unique,
senha varchar(20) not null
);
-- Comando para descrever a tabela 
 -- describe cliente;
create table cliente(
idCli int primary key auto_increment,
nomeCli varchar(100) not null,
endCli varchar(200) ,
foneCli varchar(15) not null,
emalCli varchar (50)
);
-- Criando a tabela servicos
create table servicos(
idOs int primary key auto_increment,
data_os timestamp default current_timestamp,
tipo varchar (20) not null,
situacao varchar (30) not null,
equipamento varchar (200) not null,
defeito varchar(200) not null,
servico varchar (100),
tecnico varchar (100),
valor_os decimal(10,2),
idCli int not null,
constraint forek_cli foreign key(idCli) references cliente(idCli)
);
 -- describe servicos;